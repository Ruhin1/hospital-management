
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								



@extends('Userlayout.main')

@section('content')

<h2 style="color:red;">Welcome. Your request is being Pending for approval.</h2>




@stop


