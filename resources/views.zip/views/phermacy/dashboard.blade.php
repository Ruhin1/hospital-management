
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								

@extends('layout.main')

@section('content')

<h2   style="color:red">Welcome Phermachy Section

</h2>


@stop