
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								

@extends('layout.main')

@section('content')

<h2 style="color:red;">Your Account has been suspended </h2>




@stop