
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								

@extends('layout.main')

@section('content')

<h2 style="color:red;">Welcome Account Section</h2>




@stop