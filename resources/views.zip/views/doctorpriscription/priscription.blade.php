<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<style>

#three{
	
min-height: 800px;
}



 </style>
 
</head>

<body>



<div  class="container">
  <div id="one" class="row">

    <div  >
         <b style="color:green; font-size:30px;">Dr. Sk.Moazzema Hossain</b> <br>
<span style="font-size:20px; color:darkblue;">MBBS, BCS(Health), FCPS(Medicine)<br>
<span style="color:red;">Medicine Specialst, Assistant Professor (medicine)</span><br>
Khulna Medical College, Khulna. </span>
    </div>

  </div>
  <br>
    <div style="height:10px;" id="two" >
    <div style="width:25%; float:left;" >
      <b>Name:</b> Hasan Mahbub
    </div>
    <div style="width:25%;float:left;" >
 <b>Age:</b> 30
    </div>
	    <div style="width:25%;float:left;" >
 <b>Sex:</b>Male
    </div>
	    <div style="width:25%;float:left;" >
<b>Date:</b>27/01/2021
    </div>

  </div>
  <br>
  <hr>
  
      <div id="three" >
    
	
	<div style="width:25%; float:left;" >
     Backpain <br>
	 jointpain<br>
	 1 SPA 
	<br>
	Crhim<br>
	CRP+UE
	<br>
	Adj<br>
	HLA+B2+B7<br>
	Xrg Secrilling jointpain<br>
	TSH<br>
    </div>
    
	
	
	<div style="width:75%; float:left;">
	<div >
	<div style="width:20%; float:left;" >
 <b style="font-size:30px;">Rx:</b> <br>
 </div>
 
 
 <div style="width:80%; float:right;">
 <div >
 <b>  1. Tab Remucapcer (75) </b><br><br>
 
 <div >
 <div style="width:15%; float:left; font-family:nikosh" >
 ১+০+১  
 </div>
  <div style="width:25%; float:left; font-family:nikosh;"  >
 খাবার ১ ঘন্টা আগে  
 </div>
 
   <div style="width:15%; float:left; font-family:nikosh;"  >
১ মাস 
 </div>
     <div style="width:45%; float:left; font-family:nikosh;" >
ব্যাথা করলে প্রতিদিন সকালে খাবেন।  
 </div>
 </div>
 </div>
 
 <br>
 
 </div>
 


 </div>
  


  </div>


  </div>
  <br>
   <br>
   <br>
   <br>
    <br>
	

  <div id="four">
  <div style="width:33%;float:left;">
<b style="color:red; font-family:nikosh; font-size:25px;">  সিরিয়ালের জন্য </b><br>
<span style="color:darkblue;">01912837456</span>
  </div>
  
  <div  style="width:33%;float:left;font-family:nikosh;">
 <b style="color:red;font-size:25px;">  চেম্বার </b> <br>
 খুলনা সিটি মেডিকেল কলেজ হাসপাতাল <br>
  ২৫-২৬ কেডিএ এভিনিউ <br>
  ময়লা পোতা <br>
  
  </div>
  <div style="width:33%;float:left;font-family:nikosh;">
<b style="color:red;font-size:25px;">  সাক্ষাতের সময়</b> <br>
  দুপুর ২.৩০ থেকে সন্ধ্যা ৬ টা <br>
  শুক্রবার বন্ধ 
 </div>
  </div>

</div>



    
</body>
</html>
